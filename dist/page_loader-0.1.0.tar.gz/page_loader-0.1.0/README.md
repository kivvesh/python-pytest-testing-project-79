### The page_loader package for downloading html code

Для установки пакета, используйте команду `pip install --user dist/*.whl`